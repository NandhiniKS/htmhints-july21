document.getElementById('loginBtn').addEventListener('click',function(){
    let username = document.getElementById('username').value;
    let password=document.getElementById('password').value;
    document.getElementById('username_errorMsg').innerText="";
    document.getElementById('password_errorMsg').innerText="";
   if(username==''){
    document.getElementById('username_errorMsg').innerText="Username is Required";
    document.getElementById('username_errorMsg').style.color = "red";
   }
   else if(password==''){
    document.getElementById('password_errorMsg').innerText="Password is Required";
    document.getElementById('password_errorMsg').style.color = "red";
   }else {
    alert('Logged in');
}
});