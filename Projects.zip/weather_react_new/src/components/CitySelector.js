import React, {useState} from 'react';
import {Row, Col, FormControl, Button,Card} from 'react-bootstrap';
import {API_KEY, API_BASE_URL} from '../apis/config';
import '../App.css';
const CitySelector = () => {
    const [city, setCity] = useState('');
    const [results, setResults] = useState([]);
    const [visible, setVisible] = useState(false);
    const[weathericon,Setweathericon]=useState('01d')
  
  const [icons,setIcons]=useState('');
    const onSearch = () => {
      fetch(
        `${API_BASE_URL}/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
      )
        .then((response) => response.json())
        // update the results
        .then((results) => setResults(results));
        console.log (results.length);
        if (results.length!==0){
          setVisible(true);
          console.log(results.weather[0].icon)
          Setweathericon(results.weather[0].icon);
        }
       
        console.log(results)

      
    };
  
    return (
      <>
      <div className="warpper">

    
        <Row>
           <Col>
             <h2 className="header">Search your city</h2>
          </Col>
        </Row>
  
        <Row>
          <Col xs={4} className="text-center">
            <FormControl
              placeholder="Enter city"
              onChange={(event) => setCity(event.target.value)}
              value={city}
            />
          </Col>
          
        </Row>
  
        <Row>
          <Col>
            <Button onClick={onSearch}>Check Weather</Button>
          </Col>
        </Row>
        <Row>
     
        <Card style={{width: '18rem'}} className="card-main">
                 <Card.Img
           variant="top"

             src={`http://openweathermap.org/img/wn/${ weathericon}@2x.png`}
          />
      
      <Card.Body className="card-body">
      <p>Main :  <span className="sp">{visible && results.weather[0].main}</span> </p>
          <p>Humidity : <span className="sp">{visible && results.main.humidity}</span></p>
          <p>Current Temp : <span className="sp">{visible && results.main.temp}</span> </p>
          <p>Temp Min : <span className="sp">{visible && results.main.temp_min}</span> </p>
          <p>Temp Max : <span className="sp">{visible && results.main.temp_max}</span></p>
          <p>Description : <span className="sp">{visible && results.weather[0].description}</span></p>

        </Card.Body>
    
        </Card>
       
        </Row>
        </div>
      </>
    );
  };
export default CitySelector;