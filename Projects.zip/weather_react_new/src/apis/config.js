export const API_KEY = 'a5df93821bf07fbb12930d67c583dc71';
export const API_BASE_URL = 'http://api.openweathermap.org/';